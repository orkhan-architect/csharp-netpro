﻿using System.Net;
using System.Net.Sockets;
using System.Text;

IPAddress address = IPAddress.Parse("192.168.1.103");
IPEndPoint endPoint = new IPEndPoint(address, 10057);
Socket socket = new(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

try
{
    socket.Connect(endPoint);
    while (true)
    {
        Console.Write("Enter your message: ");    
        var message = Console.ReadLine();
        socket.Send(Encoding.ASCII.GetBytes(message));

        DateTime now = DateTime.Now;
        Console.WriteLine("At " + now.TimeOfDay.Hours + ":" + now.TimeOfDay.Minutes + " from [" + address.ToString() + "] got message: " + message);
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}
finally
{
    socket.Shutdown(SocketShutdown.Both);
    socket.Close();
}