﻿using System.Net;
using System.Net.Sockets;
using System.Text;
IPAddress address = IPAddress.Parse("192.168.1.103");
IPEndPoint endPoint = new IPEndPoint(address, 10057);
Socket socket = new(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
try
{
    socket.Bind(endPoint);
    socket.Listen(5);
    string? data;

    Console.WriteLine("Waiting...");
    Socket handler = socket.Accept();
    while (true)
    {
        byte[] buffer = new byte[1024];
        var res = handler.Receive(buffer);
        data = Encoding.UTF8.GetString(buffer);
        DateTime now = DateTime.Now;
        Console.WriteLine("At " + now.TimeOfDay.Hours + ":" + now.TimeOfDay.Minutes + " from [" + address.ToString() + "] got message: " + data);
        if (data.Contains("Exit"))
        {
            handler.Shutdown(SocketShutdown.Both);
            handler.Close();
            break;
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}