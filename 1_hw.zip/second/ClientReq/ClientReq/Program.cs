﻿using System.Net;
using System.Net.Sockets;
using System.Text;

IPAddress address = IPAddress.Parse("192.168.1.103");
IPEndPoint endPoint = new IPEndPoint(address, 10057);
Socket socket = new(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

try
{
    socket.Connect(endPoint);
    while (true)
    {
        Console.WriteLine("Choose your number of the request: \n1. Show date \n2. Show time ");
        var message = Console.ReadLine();
        socket.Send(Encoding.ASCII.GetBytes(message));

        DateTime utcTime = DateTime.UtcNow;
        TimeZoneInfo tzi = TimeZoneInfo.FindSystemTimeZoneById("Azerbaijan Standard Time");
        DateTime localTime = TimeZoneInfo.ConvertTimeFromUtc(utcTime, tzi);

        if (message == "1")
        {
            Console.WriteLine("Server GMT Date is " + utcTime.Day + "-" + utcTime.Month + "-" + utcTime.Year);
        }
        else if (message == "2")
        {
            Console.WriteLine("Server GMT Time is " + utcTime.TimeOfDay);
        }            
        else
        {
            Console.WriteLine("Wrong choice");
            continue;
        }            

        socket.Shutdown(SocketShutdown.Both);
        socket.Close();
        break;
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}