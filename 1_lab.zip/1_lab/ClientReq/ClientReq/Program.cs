﻿using System.Net;
using System.Net.Sockets;
using System.Text;

IPAddress address = IPAddress.Parse("10.1.10.45");
IPEndPoint endPoint = new IPEndPoint(address, 10057);
Socket socket = new(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.IP);

try
{
    socket.Connect(endPoint);
    while (true)
    {
        Console.WriteLine("Enter your message: ");
        var message = Console.ReadLine();
        socket.Send(Encoding.ASCII.GetBytes(message));

        if (message.Contains("Exit"))
        {
            Environment.Exit(1);
            
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}
finally
{
    socket.Shutdown(SocketShutdown.Both);
    socket.Close();
}