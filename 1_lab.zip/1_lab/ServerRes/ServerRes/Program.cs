﻿using System.Net;
using System.Net.Sockets;
using System.Text;

IPAddress address = IPAddress.Parse("10.1.10.45");
IPEndPoint endPoint = new IPEndPoint(address, 10057);
Socket socket = new(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.IP);

try
{
    socket.Bind(endPoint);
    string? data;

    Console.WriteLine("Waiting...");
    
    while (true)
    {
        byte[] buffer = new byte[1024];
        var res = socket.Receive(buffer);
        data = Encoding.UTF8.GetString(buffer);
        
        DateTime now = DateTime.Now;
        Console.WriteLine("At " + now.TimeOfDay.Hours + ":" + now.TimeOfDay.Minutes + " from [" + address.ToString() + "] got message: " + data);
        
        if (data.Contains("Exit"))
        {
            socket.Shutdown(SocketShutdown.Receive);
            socket.Close();
            break;
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}